import { createStore } from 'vuex'

export default createStore({
    state: {
        playList: [{ //播放列表
            al: {
                id: 84029595,
                name: "想去海边",
                pic: 109951164966568500,
                picUrl: "https://p1.music.126.net/sLWN-iePq4ESOMPER0IWgQ==/109951164602081973.jpg",
                pic_str: "109951164602081973"
            },
            id: 1413863166,
            name: "想去海边",
            ar: [{ name: "夏日入侵企画" }]
        }],
        playListIndex: 0, //默认下标为0
        isbtnShow: true, //暂停按钮的显示
    },

    getters: {},
    mutations: {
        updateIsbtnShow: function(state, value) {
            state.isbtnShow = value
        },
        updatePlayList: function(state, value) {
            state.playList = value
            console.log(state.playList);
        },
        updatePlayListIndex: function(state, value) {
            state.playListIndex = value
            console.log(state.playListIndex);
        },
    },
    actions: {},
    modules: {}
})